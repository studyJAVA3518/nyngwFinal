package com.test.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.test.dto.GuestMessage;
import com.test.dto.GuestMessageList2;

@Controller
public class GuestMeesageListJsonController {
	   @RequestMapping(value="/guestmessage/list.json")
	   @ResponseBody
	   public GuestMessageList2 listJson(){
	      return getMessageList2();
	   }
	   
	   private GuestMessageList2 getMessageList2(){
	      List<GuestMessage> messages = Arrays.asList(
	            new GuestMessage(1,"메시지",new Date()),
	            new GuestMessage(2, "메시지",new Date())
	            );
	      return new GuestMessageList2(messages);
	   }
	   
	   @RequestMapping(value="/guestmessage/post.json", method=RequestMethod.POST)
	   @ResponseBody 
	   public GuestMessageList2 postJson(@RequestBody Map<String, Object> data){
		  List<GuestMessage> messageList = new ArrayList<GuestMessage>();
		  
		  List<Map> dataList = (List<Map>)data.get("messages");
		  	
		  for(Map message: dataList){
			  int id= (Integer)message.get("id");
			  String msg = (String)message.get("message");
			  SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd");
			  Date creationTime = null;
			  
			  try {
				creationTime = transFormat.parse((String)message.get("creationTime"));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			  
			  GuestMessage guestMessage = new GuestMessage(id,msg,creationTime);
			  
			  messageList.add(guestMessage);
			  
			  System.out.println(message.get("id"));
			  System.out.println(message.get("message"));
			  
		  }
		  return new GuestMessageList2(messageList);
	   }
}
