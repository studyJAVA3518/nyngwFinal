package com.test.controller;

import java.io.IOException;
import java.io.StringReader;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.test.dto.GuestMessage;
import com.test.dto.GuestMessageList;

@Controller
public class GuestMessageListXmlController {

	@RequestMapping("guestmessage/list.xml")
	@ResponseBody
	public GuestMessageList listXml(){
		return getMessageList();
	}

	private GuestMessageList getMessageList() {
		List<GuestMessage> messages = Arrays.asList(
					new GuestMessage(1,"메시지",new Date()),
					new GuestMessage(2,"메시지2",new Date())
				);
		return new GuestMessageList(messages);
	}
	
	@RequestMapping(value="/guestmessage/post.xml",method=RequestMethod.POST)
	@ResponseBody
	public String postXml(@RequestBody String xml){
		Document document = null;
		try {
			document = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
		} catch (SAXException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
		
		NodeList messageNodes = document.getElementsByTagName("creationTime");
		if(messageNodes.getLength()>0){
			for(int index = 0 ; index < messageNodes.getLength() ; index++){
			Element message = (Element)messageNodes.item(index);
				System.out.println(message.getTextContent());
			}
		}
		
		return "success";
	}
	
	
}
